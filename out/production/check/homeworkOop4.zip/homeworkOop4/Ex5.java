package homeworkOop4;

public class Ex5 {
    public static void main(String[] args) {
            int[] numbers = {3, 9, 8, 7, 4, 67, 45, 33, 88, 2};
            int sum = 0;
            for(int i = 0; i < 10; i++){
                sum+=numbers[i];
            }
            System.out.println(sum);
    }
}
