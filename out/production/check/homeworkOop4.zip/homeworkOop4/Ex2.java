package homeworkOop4;

public class Ex2 {
    public static void main(String[] args) {
        int n = 3;
        for(int i = 0; i <=3; i++){
            System.out.println(i +" * 3 = "+ i*n);
        }
    }
}
